1.Make dir in XULRunner directory,named "Plugins" 
2.Copy "gcswf32.dll" from Chorme directory,then rename it like this "NPSWF32.dll",then copy it in to dir of "Plugins". 
3.Copy "flashplayercplapp.cpl" in to dir of "Plugins". 
4.Copy "flashplayerapp.exe" in to dir of "XULRunner",not dir of "Plugins" then u can use it perfectly